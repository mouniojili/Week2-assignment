package com.eraser.test;

import com.eraser.AbstractFactory.ArtEraserFactory;
import com.eraser.AbstractFactory.EraserFactory;
import com.eraser.AbstractFactory.PaperEraserFactory;
import com.eraser.beans.Eraser;

public class Client {
	
	
	public static void main(String[] args) {
		
		
		Eraser paperEraser = EraserFactory.createEraser(new PaperEraserFactory(2, "White", "Rubber"));
		
		Eraser artEraser = EraserFactory.createEraser(new ArtEraserFactory(4, "Blue", "Latex"));
		
		System.out.println("Paper Eraser Object====>"+paperEraser.toString());
		System.out.println("Art Eraser Object======>"+artEraser.toString());
	} 

}
