package com.eraser.AbstractFactory;

import com.eraser.beans.Eraser;

public interface EraserAbstract {
    
	public Eraser createEraser();
}
