package com.eraser.AbstractFactory;

import com.eraser.beans.Eraser;

public class EraserFactory {
	
	public static Eraser createEraser(EraserAbstract obj) {
		return obj.createEraser();
	}

}
