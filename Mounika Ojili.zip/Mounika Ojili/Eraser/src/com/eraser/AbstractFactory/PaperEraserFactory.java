package com.eraser.AbstractFactory;

import com.eraser.beans.Eraser;
import com.eraser.beans.PaperEraser;

public class PaperEraserFactory implements EraserAbstract {

	private int size;
	private String colour;
	private String material;
	
	
	
	public PaperEraserFactory(int size, String colour, String material) {
		this.size = size;
		this.colour = colour;
		this.material = material;
	}



	@Override
	public Eraser createEraser() {
		// TODO Auto-generated method stub
		return new PaperEraser(this.size, this.colour, this.material);
	}
	
	
	

}
