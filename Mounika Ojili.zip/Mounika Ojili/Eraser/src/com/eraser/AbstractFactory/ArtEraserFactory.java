package com.eraser.AbstractFactory;

import com.eraser.beans.ArtEraser;
import com.eraser.beans.Eraser;

public class ArtEraserFactory implements EraserAbstract {

	private int size;
	private String colour;
	private String material;
	
	
	public ArtEraserFactory(int size, String colour, String material) {
		this.size = size;
		this.colour = colour;
		this.material = material;
	}


	@Override
	public Eraser createEraser() {
		// TODO Auto-generated method stub
		return new ArtEraser(this.size, this.colour,this.material);
	}

}
