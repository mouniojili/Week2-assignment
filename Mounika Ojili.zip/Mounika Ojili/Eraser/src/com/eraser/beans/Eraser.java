package com.eraser.beans;

public interface Eraser {
	
	public int getSize();
	
	public String getColour();
	
	public String getMaterial();
	
	
	

}
