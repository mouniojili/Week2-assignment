package com.eraser.beans;

public class ArtEraser implements Eraser {

	private int size;
	private String colour;
	private String material;
	
	
	
	public ArtEraser(int size, String colour, String material) {
		this.size = size;
		this.colour = colour;
		this.material = material;
	}

	@Override
	public int getSize() {
		// TODO Auto-generated method stub
		return this.size;
	}

	@Override
	public String getColour() {
		// TODO Auto-generated method stub
		return this.colour;
	}
	

	@Override
	public String getMaterial() {
		// TODO Auto-generated method stub
		return this.material;
	}

	@Override
	public String toString() {
		return "ArtEraser [size=" + size + ", colour=" + colour + ", material=" + material + "]";
	}

	
	
}
